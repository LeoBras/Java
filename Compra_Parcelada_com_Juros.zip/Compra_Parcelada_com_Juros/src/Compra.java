
public class Compra {
		private double valor;
	
		public Compra(double valor){
			this.valor = valor;
		}
		
		public double total(){
			return this.valor;
		}
		
}
