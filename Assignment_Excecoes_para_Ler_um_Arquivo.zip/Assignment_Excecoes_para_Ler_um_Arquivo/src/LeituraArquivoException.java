
public class LeituraArquivoException extends Exception {
	
}
